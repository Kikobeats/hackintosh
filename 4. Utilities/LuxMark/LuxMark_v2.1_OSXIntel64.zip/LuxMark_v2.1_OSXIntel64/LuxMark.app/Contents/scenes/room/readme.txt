Room scene is too large to be stored in the Mercurial repository.

If this directory is empty, you can download the files
from http://www.luxrender.net/release/luxmark/room_scene.zip
